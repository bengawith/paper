"""Evidence-backed viability reporting."""
